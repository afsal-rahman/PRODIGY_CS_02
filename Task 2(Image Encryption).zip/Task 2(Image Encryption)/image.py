from PIL import Image
import os

def encrypt_image(image_path, output_path):
    # Open the image
    img = Image.open(image_path)
    width, height = img.size
    
    # Encrypt by swapping pixel values
    pixels = img.load()
    for i in range(width):
        for j in range(height):
            r, g, b = pixels[i, j]
            # Example encryption (swap red and blue channels)
            pixels[i, j] = (b, g, r)
    
    # Save the encrypted image
    img.save(output_path)
    print(f"Encrypted image saved as {output_path}")

def decrypt_image(image_path, output_path):
    # Open the encrypted image
    img = Image.open(image_path)
    width, height = img.size
    
    # Decrypt by reversing the encryption process
    pixels = img.load()
    for i in range(width):
        for j in range(height):
            r, g, b = pixels[i, j]
            # Example decryption (swap red and blue channels back)
            pixels[i, j] = (b, g, r)
    
    # Save the decrypted image
    img.save(output_path)
    print(f"Decrypted image saved as {output_path}")

def main():
    # Example usage
    image_path = '/home/kali/Documents/Prodigy Info Tech/Image Encryption/input.jpg'
    encrypted_path = 'encrypted_image.jpg'
    decrypted_path = 'decrypted_image.jpg'
    
    # Encrypt the image
    encrypt_image(image_path, encrypted_path)
    
    # Decrypt the image
    decrypt_image(encrypted_path, decrypted_path)

if __name__ == "__main__":
    main()
